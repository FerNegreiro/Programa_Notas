def calcular_media(notas):
    if len(notas) == 0:
        return 0
    soma = sum(notas)
    media = soma / len(notas)
    return media

def verificar_situacao(media):
    if media < 7:
        return "Reprovado"
    elif media == 10:
        return "Parabéns, sua média é 10"
    else:
        return "Aprovado"

def main():
    notas = []
    while True:
        nota_str = input("Digite uma nota (ou digite 'fim' para encerrar): ")
        if nota_str.lower() == 'fim':
            break
        nota = float(nota_str)
        notas.append(nota)

    media = calcular_media(notas)
    situacao = verificar_situacao(media)

    print(f"A média do aluno é: {media:.2f}")
    print(f"Situação: {situacao}")

if __name__ == "__main__":
    main()
